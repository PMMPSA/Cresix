## ServerInfo
A Simple Command for players to get informations

Messages are editable in the Config.

__Poggit:__<br>
 [![Poggit](https://poggit.pmmp.io/ci.badge/FunnyBuddys/ServerInfo/ServerInfo)](https://poggit.pmmp.io/ci/FunnyBuddys/ServerInfo)<br>
### Commands:
 /serverinfo 
 
### To-Do List
- [x] Messages editable in Config


