<?php

namespace Info;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class main extends PluginBase implements Listener {

public $prefix = "§8[§aServerInfo§8] §f";

public function onEnable() {
 @mkdir($this->getDataFolder());
$this->getLogger()->info("§eLoaded!");
 }
 public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
     
     $config = new config($this->getDataFolder() . "config.yml", Config::YAML);
    
     if($config->get("info1") == null){
      $config->set("info1", "§7[§a+§7]§a /test");
      $config->save();
     }
     if($config->get("info2") == null){
      $config->set("info2", "§7[§a+§7]§a /hub");
      $config->save();
     }
     if($config->get("info3") == null){
      $config->set("info3", "");
      $config->save();
     }

     if($cmd->getName() == "serverinfo"){                 
             $sender->sendMessage("§7]=--------------------=[");
             $sender->sendMessage("  §6" . $config->get("info1"));
             $sender->sendMessage("  §6" . $config->get("info2"));
             $sender->sendMessage("  §6" . $config->get("info3"));
             $sender->sendMessage("§7]=--------------------=[");                    
         }
      }      
    }
