uSkyBlock
=========

Based on Talabrek's Ultimate SkyBlock plugin version 1.0.8

The original plugin can be found over at http://dev.bukkit.org/bukkit-plugins/ultimate-skyblock/
